// This program demonstrates the char data type.

public class Letters
{
   public static void main(String[] args)
   {
      char letter;

      letter = 'A';
      System.out.println(letter);
      letter = 'B';
      System.out.println(letter);
   }
}
