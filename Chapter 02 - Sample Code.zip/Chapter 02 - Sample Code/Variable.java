// This program has a variable.

public class Variable
{
   public static void main(String[] args)
   {
      int value;

      value = 5;
      System.out.print("The value is ");
      System.out.println(value);
   }
}
